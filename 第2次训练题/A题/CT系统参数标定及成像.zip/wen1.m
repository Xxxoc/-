R = xlsread('A�⸽��.xls',2); 
W = 512;   
theta = 1:180; 
fourier = fft(R, W); 
filter = 2*[0:(W/2-1), W/2:-1:1]'/W;   
lvbo = zeros(W,180);  
for i = 1:180   
     lvbo(:,i) = fourier(:,i).*filter;   
end

inversse = real(ifft(lvbo));   
N = 360;
final = zeros(N); 
for i = 1:180   
rad = theta(i)*pi/180; 
 for x = (-N/2+1):N/2   
 for y = (-N/2+1):N/2 
t = round(x*cos(rad+pi/2)+y*sin(rad+pi/2));   
final(x+N/2,y+N/2)=final(x+N/2,y+N/2)+inversse(t+round(size(R,1)/ 2),i);
 end
 end
end
final=final/180;
save date final;
imshow(final),title('final')
load date final