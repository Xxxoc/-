R = xlsread('A�⸽��.xls',5); 
W = 512;   
theta = 1:180; 
fourier = fft(R, W); 
filter = 2*[0:(W/2-1), W/2:-1:1]'/W;   
lvbo = zeros(W,180);   
for i = 1:180   
     lvbo(:,i) = fourier(:,i).*filter;   
end

inversse = real(ifft(lvbo));   
N = 360;
final = zeros(N); 
for i = 1:180   
rad = theta(i)*pi/180; 
 for x = (-N/2+1):N/2   
 for y = (-N/2+1):N/2 
t = round(x*cos(rad+pi/2)+y*sin(rad+pi/2));   
final(x+N/2,y+N/2)=final(x+N/2,y+N/2)+inversse(t+round(size(R,1)/ 2),i);
 end
 end
end
final=final/180;
save date final;
imshow(final),title('final')
load date final


a=100/256;
m=50-40.7286;  
n=55.9503-50;
theta=29; 
for i=1:256    
    for j=1:256  
        A=a*(j-0.5)-50+m;        
        B=50-a*(i-0.5)-n; 
        M=[cos(theta/180*pi) sin(theta/180*pi);-sin(theta/180*pi) cos(theta/180*pi)]*[A,B]'; 
        A2=M(1,1);      
        B2=M(2,1); 
        j2=ceil(((A2+180*0.2768)/0.2768)+0.5);        
        i2=ceil(((180*0.2768-B2)/0.2768)+0.5); 
        if (i2>=1) && (i2<=360) && (j2>=1) && (j2<= 360)             
            S(i,j)=final(i2,j2); 
        else
        S(i,j)=0;
        end
    end
end

imshow(S); 
S=S/0.2961; 
xlswrite('problem3.xls',S);